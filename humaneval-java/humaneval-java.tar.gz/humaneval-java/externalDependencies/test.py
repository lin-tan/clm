import json
import subprocess

baseline_info = "../src/main/java/humaneval/humaneval_loc.txt"
info_dict = {}
baseline_lines = open(baseline_info).readlines()
for line in baseline_lines:
    line = line.strip()
    file_name = line.split(" ")[0]
    loc = line.split(" ")[-1]
    loc = loc.strip()
    beginline = int(loc.split("-")[0])
    endline = int(loc.split("-")[1])
    info_dict[file_name] = [beginline, endline]


stdout = subprocess.run("java -jar ./HumanEvalExtractor/out/artifacts/HumanEvalExtractor_jar/HumanEvalExtractor.jar", shell=True, stdout=subprocess.PIPE)
output = stdout.stdout.decode('utf-8')
output_lines = output.split("\n")

out_json = "./humaneval-java-sf.json"
out_dict = {}
for line in output_lines:
    line = line.strip()
    if line.endswith(".java"):
        file_name = line.split("/")[-1].split(".")[0]
        next_line = output_lines[output_lines.index(line) + 1]
        next_line = next_line.strip()
        if "#" not in next_line:
            print(file_name + " " + next_line)
            exit(-1)
        else:
            beginline = int(next_line.split("#")[0])
            endline = int(next_line.split("#")[1])
            baseline_beginline = info_dict[file_name][0]
            baseline_endline = info_dict[file_name][1]
            if (baseline_beginline < beginline or baseline_endline > endline):
                print("error", end=None)
                print(file_name + " " + str(beginline) + "-" + str(endline))
            else:
                if "/buggy/" in line:
                    out_dict[file_name] = {}
                    src = "".join(open(line, 'r').readlines()[beginline-1:endline]).replace("\t", "    ")
                    lines = src.splitlines()
                    leading_white_space = len(lines[0]) - len(lines[0].lstrip())
                    comment = ""
                    lines = open(line, 'r').readlines()
                    record = False
                    for line in lines:
                        line = line.strip()
                        if line.startswith("//"):
                            comment +=  " "*leading_white_space + line + "\n"
                        if line.startswith("/*"):
                            record = True
                        if record:
                            comment += " "*leading_white_space + line + "\n"
                        if line.endswith("*/"):
                            record = False
                            break
                    out_dict[file_name]["buggy"] = comment + src
                    out_dict[file_name]["comment"] = comment
                    out_dict[file_name]["begin"] = beginline
                    out_dict[file_name]["end"] = endline
                elif "/correct/" in line:
                    src = "".join(open(line, 'r').readlines()[beginline-1:endline]).replace("\t", "    ")
                    out_dict[file_name]["fix"] = src

with open(out_json, 'w') as f:
    f.write(json.dumps(out_dict, indent=4))