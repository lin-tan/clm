package org.example;

import org.eclipse.jdt.core.dom.*;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {

    private static Map<String, List<Integer>> bug_to_lines = new HashMap<>();
    static int final_out_begin =  -1;
    static int final_out_end =  -1;

    static String methodName = " ";
    private static void extractMethodInfo(File path) throws IOException {
        String fileName = path.getName().split(".java")[0];
        int baselineBegin = bug_to_lines.get(fileName.toLowerCase()).get(0);
        int baselineEnd = bug_to_lines.get(fileName.toLowerCase()).get(1);
        StringBuilder buggyCode = new StringBuilder();
        BufferedReader reader = new BufferedReader(new FileReader(path));
        String currentLine = "";
        while((currentLine = reader.readLine()) != null){
            buggyCode.append(currentLine).append("\n");
        }
        ASTParser parser = ASTParser.newParser(AST.JLS8);
        parser.setSource(buggyCode.toString().toCharArray());
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        final_out_begin = -1;
        final_out_end = -1;
        CompilationUnit cu = (CompilationUnit) parser.createAST(null);
        cu.accept(new ASTVisitor() {
                    @Override
                    public boolean visit(MethodDeclaration node){
                        int beginLine = cu.getLineNumber(node.getStartPosition());
                        int endLine = cu.getLineNumber(node.getStartPosition() + node.getLength());
//                        boolean condition = beginLine <= baselineBegin && endLine >= baselineEnd && (methodName.equals(" ") || node.getName().toString().equals(methodName));
                        boolean condition = methodName.equals(" ") ? beginLine <= baselineBegin && endLine >= baselineEnd : node.getName().toString().equals(methodName);
//                        if(node.getName().toString().equalsIgnoreCase(fileName)){
                        if (condition){
                            final_out_begin = beginLine;
                            final_out_end = endLine;
                            methodName = node.getName().toString();
                            return true;
                        }
                        return true;
                    }
                }
        );
        System.out.println(final_out_begin+ "#" + final_out_end);
    }

    private static void processInfoFile(String filePath) throws IOException {
        File infoFile = new File(filePath);
        BufferedReader reader = new BufferedReader(new FileReader(infoFile));
        String currentLine = "";
        while((currentLine = reader.readLine()) != null){
            currentLine = currentLine.strip();
            currentLine = currentLine.replaceAll(" +", "#");
            String file_name = currentLine.split("#")[0];
            String range = currentLine.split("#")[1];
            int beginline, endline;
            beginline = Integer.parseInt(range.split("-")[0]);
            endline = Integer.parseInt(range.split("-")[1]);
            List<Integer> tmp = new ArrayList<>();
            tmp.add(beginline); tmp.add(endline);
            bug_to_lines.put(file_name.toLowerCase(), tmp);
        }
    }

    public static void main(String[] args) throws IOException {
        String defaultBugPath = "/Users/ffengjay/Postgraduate/PLM4APR/humaneval-java/src/main/java/humaneval/buggy/";
        String baselineInfoPath = "/Users/ffengjay/Postgraduate/PLM4APR/humaneval-java/src/main/java/humaneval/humaneval_loc.txt";
        processInfoFile(baselineInfoPath);
        File bugsDir = new File(defaultBugPath);
        File[] files = bugsDir.listFiles();
        for(File file: files){
            System.out.println(file);
            extractMethodInfo(file);
            File correctFile = new File(file.getAbsoluteFile().toString().replace("/buggy/", "/correct/"));
            System.out.println(correctFile.getAbsoluteFile().toString());
            extractMethodInfo(correctFile);
            methodName = " ";
        }
    }
}