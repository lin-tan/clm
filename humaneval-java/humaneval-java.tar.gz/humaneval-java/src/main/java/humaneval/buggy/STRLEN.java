package humaneval.buggy;

public class STRLEN {
    public static int strlen(String string){
        return string.length() - 1;
    }
}
