package humaneval.buggy;

/* Add two numbers x and y
>>> add(2, 3)
5
>>> add(5, 7)
12 */

public class ADD {
    public static int add(int x, int y) {
        return x | y;
    }
}
