package humaneval.correct;

public class STRLEN {
    public static int strlen(String string){
        return string.length();
    }
}
